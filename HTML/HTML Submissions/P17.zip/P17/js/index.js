function about(){
    alert("About");
}
function services(){
    alert("Services");
  }
function clients(){
    alert("Clients");
}
function contact() {
    alert("Contact");
  }